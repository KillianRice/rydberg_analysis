%function [fitTime,fitGndState,rabiFreq,decohFreq] = fitRabiOsc(time,atomPop,gammaLife,gammaCoh,delta)
function [fitTime,fitGndState,rabiFreq,decohFreq] = fitRabiOsc(time,atomPop,rabiParams,fitParams)
%Function to fit rabi oscillations by solving thw two level optical bloch equations with damping
%
% INPUTS:
%   time        - vector of time points where Rabi oscillations measurements were obtained
%   atomPop     - vector of Rabi oscillation ground state population data
%                 normalized to total population (i.e. max population = 1)
%
% OUTPUTS:
%   fitTime     - 
%   fitGndState -
%   rabiFreq    -
%   decohFreq   -

%% Initalize fixed parameters
% Fixed physical constants
gammaLife = rabiParams.gammaLife; % [s^-1] natural decay rate
initRho = rabiParams.initRho; % [pgg; pee; pge; peg]
rabiPulseOffset = rabiParams.pulseOffset; % [s] Offset time of Rabi pulse

%% Initial Guesses
% Initial (normalized) population guess
delta = fitParams.delta; % [s^-1] detuning from state
gammaCoh = fitParams.gammaCoh; % [s^-1] natural decay rate
totNumFit = fitParams.totNumFit; 

% Smooth data and guess Rabi frequency
smoothSpan = 5; % Smoohting span
minPeakDist = 3;
smoothNum = smooth(atomPop,smoothSpan);
[~,peakPos] = findpeaks(smoothNum,'minpeakdistance',minPeakDist);
omegaRabi = 2*pi/mean(diff(time(peakPos))); % [s^-1] guess Rabi rate from peak positions

%% Adjust data set for fitting
adjTime = [0;time + rabiPulseOffset];

switch rabiParams.state
    case 1 % If the ground state is measured
        adjAtomPop = [0;atomPop];
    case 2 % If the excited state is measured
        adjAtomPop = [1;atomPop];
    otherwise
        error('Not a valid state selection.');
end

%% Fitting Routine
% Compile guess parameters into vector
guessParams = [omegaRabi,gammaCoh,totNumFit,delta];

% Make anonymous function for fitting (see NonLinearModel.fit help about
% order of (coeffs,time)
fitCall = @(coeffs,time) fitFunc(time,initRho,coeffs(1),gammaLife,coeffs(2),coeffs(4),coeffs(3));

% Call fitting function
%oscCoeffsModel = NonLinearModel.fit(adjTime,adjAtomPop,fitCall,guessParams,...
%                                    'CoefficientNames',{'Rabi Freq.','GammaCoh','Num','Delta'});

oscCoeffsModel = lsqcurvefit(fitCall,guessParams,adjTime,adjAtomPop);

% Save coefficients into variables
% rabiFreq  = oscCoeffsModel.Coefficients.Estimate('Rabi Freq.') % [s^-1] Rabi rate
% decohFreq = oscCoeffsModel.Coefficients.Estimate('GammaCoh') % [s^-1] decoherence rate
% totNumFit = oscCoeffsModel.Coefficients.Estimate('Num') % detuning
% deltaFit = oscCoeffsModel.Coefficients.Estimate('Delta') % detuning

rabiFreq = oscCoeffsModel(1);
decohFreq = oscCoeffsModel(2);
totNumFit = oscCoeffsModel(3);
deltaFit = oscCoeffsModel(4);

rabiFreq
decohFreq
totNumFit
deltaFit

%% Get fit oscillations from OBE
fitTime     = linspace(0,max(adjTime),1e3)';
fitGndState = fitFunc(fitTime,initRho,rabiFreq,gammaLife,decohFreq,deltaFit,totNumFit);

figure
plot(fitTime,fitGndState)

end

function output = fitFunc(tRange,initRho,omegaRabi,gammaLife,gammaCoh,delta,num)
    [~,rho] = ode45(@(t,rho) funcOBE(t,rho,omegaRabi,gammaLife,gammaCoh,delta),tRange,initRho);
    output = num*rho(:,2); % Solve for ground state atom population
end

% function output = fitFunc(tRange,omegaRabi,gammaLife,gammaCoh,delta,initPop)
%     [~,rho] = ode45(@(t,rho) funcOBE(t,rho,omegaRabi,gammaLife,gammaCoh,delta),tRange,[initPop 0 0 0]);
%     output = rho(:,1); % Solve for ground state atom population
% end