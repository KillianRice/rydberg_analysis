%function [fitTime,fitGndState,rabiFreq,decohFreq] = fitRabiOsc(time,normPop,gammaLife,gammaCoh,delta)
function [fitTime,fitGndState,rabiFreq,decohFreq] = fitRabiOsc(time,normPop,rabiParams)
%Function to fit rabi oscillations by solving thw two level optical bloch equations with damping
%
% INPUTS:
%   time        - vector of time points where Rabi oscillations measurements were obtained
%   normPop     - vector of Rabi oscillation ground state population data
%                 normalized to total population (i.e. max population = 1)
%
% OUTPUTS:
%   fitTime     - 
%   fitGndState -
%   rabiFreq    -
%   decohFreq   -

%% Initalize variables
% Fixed physical constants
gammaLife = rabiParams.gammaLife; % [s^-1] natural decay rate
delta = rabiParams.delta; % [s^-1] detuning from state
gammaCoh = rabiParams.gammaCoh; % [s^-1] natural decay rate

%% Initial Guesses
% Initial (normalized) population guess
initRho = rabiParams.initRho; % [pgg; pee; pge; peg]
%initPop = normPop(1);

% Smooth data and guess Rabi frequency
smoothSpan = 5; % Smoohting span
minPeakDist = 3;
smoothNum = smooth(normPop,smoothSpan);
[~,peakPos] = findpeaks(smoothNum,'minpeakdistance',minPeakDist);
omegaRabi = 2*pi/mean(diff(time(peakPos))); % [s^-1] guess Rabi rate from peak positions


% % Fit to decaying sin^2 to get better estimate of Rabi frequency and decay time
% expsin2 = @(a,t0,omega,gamma,t) a+sin(omega*(t-t0)).^2.*exp(-gamma*t);
% lsqexpsin = @(p,t)expsin2(p(1),p(2),p(3),p(4),t);
% 
% init = [0.5,0,omegaRabi/2,gammaLife+gammaCoh];
% [newparams,~] = lsqcurvefit(lsqexpsin, init, time, smoothNum);
% figure;
% hold on;
% plot(time, lsqexpsin(newparams, time))
% plot(time, smoothNum)
% hold off;
% gammaCoh = newparams(4) - gammaLife
% omegaRabi = newparams(3)

%% Fitting Routine
% Compile guesses into vector
%initGuesses = [omegaRabi gammaCoh initPop];
initGuesses = [omegaRabi gammaCoh];

% Make anonymous function for fitting
fitCall = @(coeffs,time) fitFunc(time,initRho,coeffs(1),gammaLife,coeffs(2),delta);

% Call fitting function
oscCoeffsModel = NonLinearModel.fit(time,normPop,fitCall,initGuesses,'CoefficientNames',{'Rabi Freq.' 'GammaCoh'});
%oscCoeffsModel = NonLinearModel.fit(time,normPop,fitCall,initGuesses,'CoefficientNames',{'Rabi Freq.' 'GammaCoh' 'Initial Population'});

% Save coefficients into variables
rabiFreq  = oscCoeffsModel.Coefficients.Estimate('Rabi Freq.'); % [s^-1] Rabi rate
decohFreq = oscCoeffsModel.Coefficients.Estimate('GammaCoh'); % [s^-1] decoherence rate
%fitInitPop = oscCoeffsModel.Coefficients.Estimate('Initial Population')

%% Get fit oscillations from OBE
fitTime     = linspace(0,max(time),1e3)';
fitGndState = fitFunc(fitTime,initRho,rabiFreq,gammaLife,decohFreq,delta);

%fitTime     = linspace(min(time),max(time),1e3)';
%fitGndState = fitFunc(fitTime,rabiFreq,gammaLife,decohFreq,delta,fitInitPop);

end

function output = fitFunc(tRange,initRho,omegaRabi,gammaLife,gammaCoh,delta)
    [~,rho] = ode45(@(t,rho) funcOBE(t,rho,omegaRabi,gammaLife,gammaCoh,delta),tRange,initRho);
    output = rho(:,1); % Solve for ground state atom population
end

% function output = fitFunc(tRange,omegaRabi,gammaLife,gammaCoh,delta,initPop)
%     [~,rho] = ode45(@(t,rho) funcOBE(t,rho,omegaRabi,gammaLife,gammaCoh,delta),tRange,[initPop 0 0 0]);
%     output = rho(:,1); % Solve for ground state atom population
% end